﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;


namespace SHERIF
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //private static string RX = "";
        int RS = 0;

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count != 0)
            {
                
                if (serialPort1.IsOpen == false)
                {
                    serialPort1.PortName = (listView1.SelectedItems[0].SubItems[0].Text);
                    serialPort1.BaudRate = Convert.ToInt32(baud.Text);
                    serialPort1.DataBits = Convert.ToInt32(bits.Text);

                    serialPort1.Open();
                    sw = '0';
                    timer1.Start();
                    count = 0;

                    toolStripStatusLabel1.Text = "Status : Connected To Port " + listView1.SelectedItems[0].SubItems[0].Text;
                    toolStripStatusLabel1.ForeColor = Color.Green;
                    button1.Enabled = false;
                    button4.Enabled = true;
                }
                else { MessageBox.Show("Port is already opened by another program", "Error"); }
            }
            else
            {
                MessageBox.Show("Plz Select Port !");
            }
        }

        char sw = '0';
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try
            {
                RS = serialPort1.ReadByte();

                this.Invoke(new EventHandler(disp));
            }
            catch (System.TimeoutException) { }
            finally
            {
                if (sw == '1')
                {
                    serialPort1.Close();
                }
            }
        }
        int count = 0;
        private void disp(object s,EventArgs e)
        {          
                textBox2.Text += RS.ToString();
               // textBox2.Text += 
                count++;        
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen == false)
            {
                MessageBox.Show("please Connect to the port","Error");
            }
            else  serialPort1.Write(textBox1.Text);
        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            
            if (serialPort1.IsOpen == true)
            {
                //serialPort1.Dispose();
                sw = '1';
                timer1.Stop();
                toolStripStatusLabel1.Text = "Status : Not Connected";
                toolStripStatusLabel1.ForeColor = Color.Red;
                button1.Enabled = true;
                button4.Enabled = false;

            }
            else { MessageBox.Show("Port is Closed", "Error"); }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            string[] ports = SerialPort.GetPortNames();
            foreach (string port in ports)
            {
                ListViewItem item = new ListViewItem(port);
                item.SubItems.Add(port);                
                listView1.Items.Add(item);
            }
        
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            textBox3.Text = count.ToString();
            
            timer1.Start();
            count = 0;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            sw = '1';
            MessageBox.Show("plz close the connection next time");
        }



    }
}
